# COMP30024 Artificial Intelligence, Semester 1 2024
# Project Part B: Game Playing Agent

GAME_NAME       = "Tetress"
NUM_PLAYERS     = 2

BOARD_N         = 11
MAX_TURNS       = 150
